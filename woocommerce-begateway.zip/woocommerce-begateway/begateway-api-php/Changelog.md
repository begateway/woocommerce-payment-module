## Changelog

### 2.2.0

  * Rename ``GetPaymentPageToken`` class to ``GetPaymentToken``
