<?php
namespace BeGateway\PaymentMethod;

class CreditCard extends Base {
}
