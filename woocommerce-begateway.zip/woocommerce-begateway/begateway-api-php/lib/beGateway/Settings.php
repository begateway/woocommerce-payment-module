<?php

namespace beGateway;

class Settings {
  public static $shopId;
  public static $shopKey;
  public static $shopPubKey;
  public static $gatewayBase  = 'https://demo-gateway.begateway.com';
  public static $checkoutBase = 'https://checkout.begateway.com';
  public static $apiBase      = 'https://api.begateway.com';
}
?>
